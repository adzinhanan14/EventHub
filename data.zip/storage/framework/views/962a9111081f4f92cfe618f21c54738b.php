<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Panitia - AmikomEventHub</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>

<body class="bg-slate-50 text-slate-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-indigo-900 text-indigo-100 flex flex-col p-6 space-y-8 sticky top-0 h-screen">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-900 font-bold text-xl">AH</div>
            <span class="text-lg font-bold text-white tracking-tight leading-tight"><?php echo e(Auth::user()->organization->name ?? 'Panel Panitia'); ?></span>
        </div>
        <nav class="flex-1 space-y-2">
            <p class="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-4 px-2">Main Menu</p>

            <a href="<?php echo e(route('organizer.dashboard')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('organizer.dashboard') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>
                </svg>
                Dashboard
            </a>

            <a href="<?php echo e(route('organizer.events.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('organizer.events.*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
                Event Saya
            </a>

            <a href="<?php echo e(route('organizer.coupons.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('organizer.coupons*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
                Kupon & Voucher
            </a>

            <a href="<?php echo e(route('organizer.checkin.scanner')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('organizer.checkin*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M12 4v1m6 11h2m-6 0h-2m-6 0H4m2-11H4m14 0h2M9 7h6v6H9V7z"></path>
                </svg>
                Check-in Scanner
            </a>

            <a href="<?php echo e(route('organizations.show', Auth::user()->organization->slug ?? '')); ?>" target="_blank"
               class="flex items-center gap-3 px-4 py-3 hover:bg-indigo-800 rounded-xl font-bold transition">
                <svg class="w-5 h-5 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"></path>
                </svg>
                Lihat Profil Publik
            </a>
        </nav>

        <div class="pt-6 border-t border-indigo-800">
            <form action="<?php echo e(route('organizer.logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="w-full flex items-center gap-3 px-4 py-3 text-indigo-300 hover:text-white hover:bg-indigo-800 rounded-xl transition font-medium text-left">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                    </svg>
                    Keluar
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10 overflow-y-auto w-full">
        <header class="flex justify-between items-center mb-10 w-full col-span-full">
            <div>
                <h1 class="text-3xl font-black"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>
                <p class="text-slate-500 font-medium"><?php echo $__env->yieldContent('page_subtitle', 'Selamat datang kembali!'); ?></p>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden md:block">
                    <p class="font-bold"><?php echo e(Auth::user()->name ?? 'Panitia'); ?></p>
                    <p class="text-xs text-slate-400"><?php echo e(Auth::user()->organization->name ?? '-'); ?></p>
                </div>
                <div class="w-12 h-12 bg-white rounded-2xl shadow-sm border flex items-center justify-center p-1">
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(Auth::user()->name ?? 'P')); ?>&background=6366f1&color=fff"
                         class="rounded-xl">
                </div>
            </div>
        </header>

        <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6 font-bold text-sm"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="bg-red-100 text-red-700 p-4 rounded-xl mb-6 font-bold text-sm"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/layouts/organizer.blade.php ENDPATH**/ ?>