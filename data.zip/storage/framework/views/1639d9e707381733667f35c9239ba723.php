<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                </path>
            </svg>
        </div>
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Total Pendapatan</p>
        <h3 class="text-2xl font-black">Rp <?php echo e(number_format($totalPendapatan ?? 0, 0, ',', '.')); ?></h3>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div class="w-12 h-12 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z">
                </path>
            </svg>
        </div>
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Tiket Terjual</p>
        <h3 class="text-2xl font-black"><?php echo e($totalTiketTerjual ?? 0); ?></h3>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div class="w-12 h-12 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center mb-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </div>
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Event Aktif</p>
        <h3 class="text-2xl font-black"><?php echo e($totalEvent ?? 0); ?> Event</h3>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <div class="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mb-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </div>
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Pesanan Pending</p>
        <h3 class="text-2xl font-black"><?php echo e($transaksiPending ?? 0); ?> Pesanan</h3>
    </div>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Total Organisasi/HIMA</p>
        <h3 class="text-2xl font-black"><?php echo e($totalOrganisasi ?? 0); ?></h3>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-amber-100 shadow-sm">
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Menunggu Verifikasi</p>
        <h3 class="text-2xl font-black text-amber-500"><?php echo e($organisasiPending ?? 0); ?></h3>
        <?php if(($organisasiPending ?? 0) > 0): ?>
        <a href="<?php echo e(route('admin.organizations.index', ['status' => 'pending'])); ?>" class="text-xs font-bold text-indigo-600 hover:underline">Tinjau sekarang &rarr;</a>
        <?php endif; ?>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <p class="text-slate-400 text-sm font-bold uppercase mb-1">Total Pembeli Terdaftar</p>
        <h3 class="text-2xl font-black"><?php echo e($totalPembeli ?? 0); ?></h3>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10">
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <h3 class="font-bold text-lg mb-4">Tren Pendapatan Platform (6 Bulan)</h3>
        <canvas id="revenueChart" height="140"></canvas>
    </div>
    <div class="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <h3 class="font-bold text-lg mb-4">Pertumbuhan Pengguna Baru (6 Bulan)</h3>
        <canvas id="userGrowthChart" height="140"></canvas>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revenueChart['labels'], 15, 512) ?>,
            datasets: [{ label: 'Pendapatan (Rp)', data: <?php echo json_encode($revenueChart['data'], 15, 512) ?>, borderColor: '#4f46e5', backgroundColor: 'rgba(79,70,229,0.1)', fill: true, tension: 0.4 }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });
    new Chart(document.getElementById('userGrowthChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($userGrowthChart['labels'], 15, 512) ?>,
            datasets: [{ label: 'Pengguna Baru', data: <?php echo json_encode($userGrowthChart['data'], 15, 512) ?>, backgroundColor: '#10b981', borderRadius: 8 }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });
</script>

<!-- Latest Sales Table -->
<div class="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
    <div class="p-8 border-b flex justify-between items-center">
        <h3 class="font-black text-xl">Transaksi Terakhir</h3>
        
        <a href="<?php echo e(route('admin.transactions.index')); ?>" class="text-indigo-600 font-bold hover:underline">Lihat Semua</a>
    </div>
    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead class="bg-slate-50 text-slate-400 uppercase text-[10px] font-black tracking-widest">
                <tr>
                    <th class="px-8 py-4">Pembeli</th>
                    <th class="px-8 py-4">Event</th>
                    <th class="px-8 py-4">Status</th>
                    <th class="px-8 py-4">Total</th>
                </tr>
            </thead>
            <tbody class="divide-y border-t">
                <?php $__empty_1 = true; $__currentLoopData = $transaksiTerakhir ?? collect(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50 transition">
                    <td class="px-8 py-6">
                        <p class="font-bold uppercase tracking-wide text-sm"><?php echo e($trx->customer_name ?? '-'); ?></p>
                        <p class="text-xs text-slate-400"><?php echo e($trx->customer_email ?? ''); ?></p>
                    </td>
                    <td class="px-8 py-6 font-medium text-slate-600"><?php echo e($trx->event->title ?? '-'); ?></td>
                    <td class="px-8 py-6">
                        <?php ($status = $trx->status); ?>
                        <?php ($badge = match($status) {
                            'Success'    => 'bg-green-100 text-green-700',
                            'Pending'    => 'bg-orange-100 text-orange-700',
                            'settlement' => 'bg-green-100 text-green-700',
                            'pending'    => 'bg-orange-100 text-orange-700',
                            default      => 'bg-slate-100 text-slate-600',
                        }); ?>
                        <span class="px-3 py-1 <?php echo e($badge); ?> rounded-lg text-xs font-bold uppercase"><?php echo e($status); ?></span>
                    </td>
                    <td class="px-8 py-6 font-black text-indigo-600">
                        Rp <?php echo e(number_format($trx->total_price ?? 0, 0, ',', '.')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="px-8 py-6 text-center text-slate-500">Belum ada transaksi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Events Grid -->
<div class="mt-10">
    <h3 class="font-black text-xl mb-6">Event Terbaru</h3>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="group bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-300 overflow-hidden">
            <div class="relative overflow-hidden aspect-[3/4]">
                <?php if($event->poster_path): ?>
                <img src="<?php echo e(asset('storage/' . $event->poster_path)); ?>" alt="<?php echo e($event->title); ?>"
                    class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <?php else: ?>
                <img src="https://placehold.co/400x500" alt="<?php echo e($event->title); ?>"
                    class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <?php endif; ?>
                <div class="absolute top-4 left-4 px-3 py-1 bg-white/90 backdrop-blur rounded-lg text-xs font-bold uppercase text-indigo-600">
                    <?php echo e($event->category->name ?? 'Umum'); ?>

                </div>
            </div>
            <div class="p-6">
                <h3 class="text-xl font-bold mb-2 group-hover:text-indigo-600 transition"><?php echo e($event->title); ?></h3>
                <div class="flex items-center gap-2 text-slate-500 text-sm mb-4">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span><?php echo e($event->date->format('d M Y, H:i')); ?></span>
                </div>
                <div class="flex justify-between items-center pt-4 border-t">
                    <span class="text-2xl font-black text-indigo-600">
                        Rp <?php echo e(number_format($event->price, 0, ',', '.')); ?>

                    </span>
                    <a href="<?php echo e(route('admin.events.edit', $event->id)); ?>"
                        class="px-5 py-2 bg-indigo-50 text-indigo-600 rounded-xl font-bold hover:bg-indigo-600 hover:text-white transition">
                        Kelola
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-3 text-center py-20">
            <p class="text-slate-500 text-lg">Belum ada event yang tersedia.</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>