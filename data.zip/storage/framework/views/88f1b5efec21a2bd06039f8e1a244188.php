<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
    @page { margin: 0; }
    * { box-sizing: border-box; }
    body {
        margin: 0;
        font-family: 'Helvetica', Arial, sans-serif;
        background: #ffffff;
    }
    .certificate {
        position: relative;
        width: 900px;
        height: 636px;
        margin: 0 auto;
        overflow: hidden;
        background: linear-gradient(160deg, #0c1f42 0%, #123064 45%, #0a1830 100%);
        color: #ffffff;
        text-align: center;
    }

    .wedge {
        position: absolute;
        bottom: 0;
        width: 0;
        height: 0;
        border-style: solid;
    }
    .wedge-outer-left {
        left: 0;
        border-width: 0 0 340px 460px;
        border-color: transparent transparent #d9ae56 transparent;
        opacity: 0.95;
    }
    .wedge-outer-right {
        right: 0;
        border-width: 0 460px 340px 0;
        border-color: transparent transparent #d9ae56 transparent;
        opacity: 0.95;
    }
    .wedge-inner-left {
        left: 0;
        border-width: 0 0 300px 400px;
        border-color: transparent transparent #0c1f42 transparent;
    }
    .wedge-inner-right {
        right: 0;
        border-width: 0 400px 300px 0;
        border-color: transparent transparent #0c1f42 transparent;
    }
    .wedge-accent-left {
        left: 0;
        border-width: 0 0 260px 340px;
        border-color: transparent transparent #1a3a75 transparent;
    }
    .wedge-accent-right {
        right: 0;
        border-width: 0 340px 260px 0;
        border-color: transparent transparent #1a3a75 transparent;
    }

    .mosaic {
        position: absolute;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 0 0 22px 22px;
        border-color: transparent transparent rgba(255,255,255,0.18) transparent;
    }

    .content {
        position: relative;
        z-index: 5;
        padding: 55px 70px 40px;
    }

    .title {
        font-size: 46px;
        font-weight: 800;
        letter-spacing: 3px;
        margin: 0;
        color: #ffffff;
    }
    .subtitle {
        font-size: 17px;
        letter-spacing: 8px;
        font-weight: 300;
        margin: 6px 0 0;
        color: #e7e9f2;
    }

    .presented {
        margin-top: 42px;
        font-size: 14px;
        letter-spacing: 4px;
        font-weight: bold;
        color: #e4b256;
    }

    .name {
        font-family: 'Brush Script MT', 'Segoe Script', 'Lucida Handwriting', cursive;
        font-size: 58px;
        color: #f0c775;
        margin: 8px 0 4px;
        line-height: 1.1;
    }
    .name-underline {
        width: 340px;
        height: 1px;
        background: rgba(255,255,255,0.4);
        margin: 6px auto 22px;
    }

    .desc {
        font-size: 12.5px;
        line-height: 1.7;
        color: #cfd6e8;
        max-width: 560px;
        margin: 0 auto;
    }

    .footer {
        margin-top: 46px;
        display: table;
        width: 100%;
        table-layout: fixed;
    }
    .footer-cell {
        display: table-cell;
        vertical-align: middle;
        width: 33.33%;
    }
    .line-label {
        border-top: 1px solid rgba(255,255,255,0.5);
        width: 150px;
        margin: 0 auto;
        padding-top: 8px;
        font-size: 11px;
        letter-spacing: 2px;
        color: #e7e9f2;
    }

    .seal {
        width: 92px;
        height: 92px;
        border-radius: 50%;
        margin: 0 auto;
        background: radial-gradient(circle at 35% 30%, #fbe2a0, #d9ae56 60%, #a97c26 100%);
        border: 3px solid #8a6a1f;
        position: relative;
        display: table;
    }
    .seal-inner {
        display: table-cell;
        vertical-align: middle;
        text-align: center;
        font-size: 9px;
        font-weight: bold;
        color: #5a3f0f;
        letter-spacing: 1px;
        line-height: 1.4;
    }
    .ribbon-wrap {
        position: relative;
        height: 40px;
        margin-top: -3px;
    }
    .ribbon {
        position: absolute;
        top: 0;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 40px 18px 0 18px;
    }
    .ribbon-left { left: 50%; margin-left: -34px; border-color: #a97c26 transparent transparent transparent; }
    .ribbon-right { left: 50%; margin-left: 2px; border-color: #d9ae56 transparent transparent transparent; }

    .meta {
        margin-top: 26px;
        font-size: 10px;
        letter-spacing: 1px;
        color: #7c86a3;
    }
</style>
</head>
<body>
    <div class="certificate">
        <div class="wedge wedge-outer-left"></div>
        <div class="wedge wedge-outer-right"></div>
        <div class="wedge wedge-accent-left"></div>
        <div class="wedge wedge-accent-right"></div>
        <div class="wedge wedge-inner-left"></div>
        <div class="wedge wedge-inner-right"></div>

        <div class="mosaic" style="left:20px; bottom:140px;"></div>
        <div class="mosaic" style="left:55px; bottom:110px;"></div>
        <div class="mosaic" style="left:20px; bottom:80px;"></div>
        <div class="mosaic" style="right:20px; bottom:140px;"></div>
        <div class="mosaic" style="right:55px; bottom:110px;"></div>
        <div class="mosaic" style="right:20px; bottom:80px;"></div>

        <div class="content">
            <p class="title">CERTIFICATE</p>
            <p class="subtitle">OF ATTENDANCE</p>

            <p class="presented">PROUDLY PRESENTED TO</p>
            <p class="name"><?php echo e($name); ?></p>
            <div class="name-underline"></div>

            <p class="desc">
                telah hadir dan berpartisipasi secara resmi pada acara
                <strong><?php echo e($eventTitle); ?></strong>
                yang diselenggarakan pada <?php echo e(\Carbon\Carbon::parse($eventDate)->translatedFormat('d F Y')); ?> oleh
                <?php echo e($organizationName); ?>

            </p>

            <div class="footer">
                <div class="footer-cell">
                    <div class="line-label"><?php echo e(\Carbon\Carbon::parse($eventDate)->translatedFormat('d F Y')); ?></div>
                </div>
                <div class="footer-cell">
                    <div class="seal">
                        <div class="seal-inner">AMIKOM<br>EVENT<br>HUB</div>
                    </div>
                    <div class="ribbon-wrap">
                        <div class="ribbon ribbon-left"></div>
                        <div class="ribbon ribbon-right"></div>
                    </div>
                </div>
                <div class="footer-cell">
                    <div class="line-label"><?php echo e($organizationName); ?></div>
                </div>
            </div>

            <p class="meta">Diterbitkan otomatis oleh AmikomEventHub &middot; No. Order: <?php echo e($orderId); ?></p>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/certificates/template.blade.php ENDPATH**/ ?>