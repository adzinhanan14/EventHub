<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AmikomEventHub</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link
        href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
    </style>
</head>

<body class="bg-slate-50 text-slate-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-indigo-900 text-indigo-100 flex flex-col p-6 space-y-8 sticky top-0 h-screen">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-indigo-900 font-bold text-xl">AH</div>
            <span class="text-xl font-bold text-white tracking-tight">AmikomEventHub</span>
        </div>
        <nav class="flex-1 space-y-2">
            <p class="text-[10px] font-bold uppercase tracking-widest text-indigo-400 mb-4 px-2">Main Menu</p>
            <a href="<?php echo e(route('admin.dashboard')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.dashboard') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z">
                    </path>
                </svg>
                Dashboard
            </a>

            <a href="<?php echo e(route('admin.organizations.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.organizations*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.organizations*') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1a4 4 0 100-8 4 4 0 000 8zm6 3v-1a4 4 0 00-3-3.87M5 12v-1a4 4 0 013-3.87">
                    </path>
                </svg>
                Organisasi/HIMA
                <?php if(($organisasiPendingCount ?? \App\Models\Organization::where('status','pending')->count()) > 0): ?>
                    <span class="ml-auto bg-amber-400 text-indigo-950 text-[10px] font-black px-2 py-0.5 rounded-full"><?php echo e($organisasiPendingCount ?? \App\Models\Organization::where('status','pending')->count()); ?></span>
                <?php endif; ?>
            </a>

            <a href="<?php echo e(route('admin.events.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.events.*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.events.*') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z">
                    </path>
                </svg>
                Kelola Event
            </a>

            <a href="<?php echo e(route('admin.categories.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.categories*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.categories*') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A4.002 4.002 0 017 3z">
                    </path>
                </svg>
                Kelola Kategori
            </a>

            <a href="<?php echo e(route('admin.partners.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.partners*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.partners*') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m16 0h-2m-12 0h2m4-16v4m0 0V9m0 0v4m0 0v4">
                    </path>
                </svg>
                Kelola Partner
            </a>

            
            <a href="<?php echo e(route('admin.transactions.index')); ?>"
               class="flex items-center gap-3 px-4 py-3 <?php echo e(request()->routeIs('admin.transactions*') ? 'bg-indigo-800 text-white' : 'hover:bg-indigo-800'); ?> rounded-xl font-bold transition">
                <svg class="w-5 h-5 <?php echo e(request()->routeIs('admin.transactions*') ? 'text-indigo-300' : 'text-indigo-400'); ?>"
                     fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z">
                    </path>
                </svg>
                Laporan Transaksi
            </a>
        </nav>

        <div class="pt-6 border-t border-indigo-800">
            <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit"
                    class="w-full flex items-center gap-3 px-4 py-3 text-indigo-300 hover:text-white hover:bg-indigo-800 rounded-xl transition font-medium text-left">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1">
                        </path>
                    </svg>
                    Keluar
                </button>
            </form>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 p-10 overflow-y-auto w-full">
        <header class="flex justify-between items-center mb-10 w-full col-span-full">
            <div>
                <h1 class="text-3xl font-black"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></h1>
                <p class="text-slate-500 font-medium"><?php echo $__env->yieldContent('page_subtitle', 'Selamat datang kembali, Admin!'); ?></p>
            </div>
            <div class="flex items-center gap-4">
                <div class="text-right hidden md:block">
                    <p class="font-bold"><?php echo e(Auth::user()->name ?? 'Admin'); ?></p>
                    <p class="text-xs text-slate-400">Penyelenggara Utama</p>
                </div>
                <div class="w-12 h-12 bg-white rounded-2xl shadow-sm border flex items-center justify-center p-1">
                    <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode(Auth::user()->name ?? 'Admin')); ?>&background=6366f1&color=fff"
                         class="rounded-xl">
                </div>
            </div>
        </header>

        <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6 font-bold text-sm">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>

</html><?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/layouts/admin.blade.php ENDPATH**/ ?>