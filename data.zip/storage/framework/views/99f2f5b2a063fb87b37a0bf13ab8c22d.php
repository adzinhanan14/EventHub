<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="font-family: sans-serif; background:#f8fafc; padding:40px;">
    <div style="max-width:500px;margin:0 auto;background:#fff;border-radius:24px;padding:32px;">
        <h2 style="color:#4f46e5;">🎓 Sertifikat Kehadiran Anda</h2>
       <h2>Halo, <?php echo e($transaction->customer_name); ?>!</h2>
        <p>Terima kasih telah berpartisipasi dalam event <strong><?php echo e($transaction->event->title); ?></strong>.</p>
        <p>Sertifikat keikutsertaan Anda telah terbit dan kami lampirkan dalam bentuk file PDF pada email ini.</p>
        <br>
        <p>Salam hangat,</p>
        <p><strong>Panitia Amikom Event Hub</strong></p>
        <p style="color:#94a3b8;font-size:12px;margin-top:32px;">Order ID: <?php echo e($transaction->order_id); ?> &middot; AmikomEventHub</p>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/emails/certificate-notice.blade.php ENDPATH**/ ?>