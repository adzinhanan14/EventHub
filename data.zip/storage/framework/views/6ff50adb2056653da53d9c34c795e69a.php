<?php $__env->startSection('page_title', 'Dashboard'); ?>
<?php $__env->startSection('page_subtitle', 'Ringkasan performa organisasi Anda'); ?>

<?php $__env->startSection('content'); ?>

<?php if($organization->isPending()): ?>
<div class="bg-amber-100 border border-amber-300 text-amber-800 p-4 rounded-xl mb-6 font-semibold text-sm">
    Organisasi Anda masih berstatus <b>menunggu verifikasi</b> Superadmin.
</div>
<?php endif; ?>

<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
    <div class="bg-white p-6 rounded-3xl shadow-sm border">
        <p class="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Total Pendapatan</p>
        <p class="text-2xl font-black text-indigo-600">Rp <?php echo e(number_format($totalPendapatan, 0, ',', '.')); ?></p>
    </div>
    <div class="bg-white p-6 rounded-3xl shadow-sm border">
        <p class="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Tiket Terjual</p>
        <p class="text-2xl font-black"><?php echo e($totalTiketTerjual); ?></p>
    </div>
    <div class="bg-white p-6 rounded-3xl shadow-sm border">
        <p class="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Total Event</p>
        <p class="text-2xl font-black"><?php echo e($totalEvent); ?></p>
    </div>
    <div class="bg-white p-6 rounded-3xl shadow-sm border">
        <p class="text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">Rating Rata-rata</p>
        <p class="text-2xl font-black text-amber-500">⭐ <?php echo e($ratingRataRata ?: '-'); ?></p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
    <div class="lg:col-span-2 bg-white p-6 rounded-3xl shadow-sm border">
        <h3 class="font-bold text-lg mb-4">Tren Pendapatan (6 Bulan Terakhir)</h3>
        <canvas id="revenueChart" height="110"></canvas>
    </div>
    <div class="bg-white p-6 rounded-3xl shadow-sm border">
        <h3 class="font-bold text-lg mb-4">Transaksi Terbaru</h3>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $transaksiTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex justify-between items-center text-sm">
                <div>
                    <p class="font-bold"><?php echo e(Str::limit($trx->customer_name, 18)); ?></p>
                    <p class="text-slate-400 text-xs"><?php echo e(Str::limit($trx->event->title ?? '-', 20)); ?></p>
                </div>
                <span class="px-2 py-1 rounded-lg text-xs font-bold <?php echo e($trx->status === 'Success' ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600'); ?>">
                    <?php echo e($trx->status); ?>

                </span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-slate-400 text-sm">Belum ada transaksi.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="bg-white p-6 rounded-3xl shadow-sm border">
    <div class="flex justify-between items-center mb-4">
        <h3 class="font-bold text-lg">Event Terbaru</h3>
        <a href="<?php echo e(route('organizer.events.create')); ?>" class="text-sm font-bold text-indigo-600 hover:underline">+ Buat Event</a>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="border rounded-2xl p-4">
            <p class="font-bold"><?php echo e($event->title); ?></p>
            <p class="text-xs text-slate-400"><?php echo e($event->category->name ?? '-'); ?> &middot; <?php echo e($event->date?->translatedFormat('d M Y')); ?></p>
            <p class="text-xs text-slate-500 mt-2">Stok: <?php echo e($event->stock); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-slate-400 text-sm">Belum ada event. Yuk buat event pertama Anda!</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    new Chart(document.getElementById('revenueChart'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($revenueChart['labels'], 15, 512) ?>,
            datasets: [{
                label: 'Pendapatan (Rp)',
                data: <?php echo json_encode($revenueChart['data'], 15, 512) ?>,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79,70,229,0.1)',
                fill: true,
                tension: 0.4,
            }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\db_uas\amikomeventhub-3405-main\resources\views/organizer/dashboard.blade.php ENDPATH**/ ?>